const mySwiper = new Swiper("#mySwiper", {
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
  pagination: {
    // el: ".swiper-pagination",
    el: ".history_progressbar",
    type: "progressbar",
  },
  sliedsPerView: 1,
  breakpoints: {
    580: {
      sliedsPerView: 2,
    },
    1200: {
      sliedsPerView: 3,
    },
  },
});

const boxes = document.querySelectorAll("history_box");
